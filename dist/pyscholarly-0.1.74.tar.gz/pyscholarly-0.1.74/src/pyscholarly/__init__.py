from .scholarly import Scholar,fetch_scholar_data, fetch_multiple_scholars 

__version__ = "0.1.0"
__all__ = ["Scholar", "fetch_scholar_data"]
